# KnightMoves

Sample program that calculates the number of moves it would take a knight to get to a specific spot on an infinite chess board. Pseudo code soon
